from flask import Flask, render_template, jsonify, request
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

# Game state
game_state = {
    'home': {
        'name': 'Home',
        'abbr': 'HOM',
        'score': {'R': 0, 'H': 0, 'E': 0},
        'lineup': [],
        'pitchers': [],
        'current_batter_index': 0,
        'current_pitcher_index': 0
    },
    'away': {
        'name': 'Away',
        'abbr': 'AWY',
        'score': {'R': 0, 'H': 0, 'E': 0},
        'lineup': [],
        'pitchers': [],
        'current_batter_index': 0,
        'current_pitcher_index': 0
    },
    'inning': 1,
    'top_inning': True,
    'outs': 0,
    'balls': 0,
    'strikes': 0,
    'bases': {'first': False, 'second': False, 'third': False}
}

# Initialize lineup with 9 slots
def init_lineup():
    lineup = []
    for i in range(9):
        lineup.append({
            'name': '',
            'number': '',
            'position': '',
            'at_bats': 0,
            'hits': 0,
            'game_stats': {'1B': 0, '2B': 0, '3B': 0, 'HR': 0, 'BB': 0, 'K': 0, 'OUT': 0}
        })
    return lineup

def init_pitcher():
    return {
        'name': '',
        'number': '',
        'pitch_count': 0,
        'strikes': 0,
        'balls': 0,
        'outs_recorded': 0,
        'strikeouts': 0,
        'walks': 0,
        'hits_allowed': 0,
        'runs_allowed': 0
    }

game_state['away']['lineup'] = init_lineup()
game_state['home']['lineup'] = init_lineup()

# Undo history (stores up to 10 states)
undo_history = []
max_undo_history = 10

def save_state_to_history():
    """Save current game state to undo history"""
    import copy
    state_copy = copy.deepcopy(game_state)
    undo_history.append(state_copy)
    if len(undo_history) > max_undo_history:
        undo_history.pop(0)  # Remove oldest state

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/state')
def get_state():
    # Ensure both teams have exactly 9 lineup slots
    for team in ['away', 'home']:
        while len(game_state[team]['lineup']) < 9:
            game_state[team]['lineup'].append({
                'name': '',
                'number': '',
                'position': '',
                'at_bats': 0,
                'hits': 0,
                'game_stats': {'1B': 0, '2B': 0, '3B': 0, 'HR': 0, 'BB': 0, 'K': 0, 'OUT': 0}
            })
    return jsonify({**game_state, 'undo_available': len(undo_history) > 0})

@app.route('/api/undo', methods=['POST'])
def undo_action():
    """Undo the last action"""
    global game_state
    if len(undo_history) > 0:
        game_state.clear()
        game_state.update(undo_history.pop())
        return jsonify({'success': True, 'undo_available': len(undo_history) > 0})
    return jsonify({'success': False, 'message': 'No actions to undo'})

@app.route('/api/vmix')
def vmix_output():
    batting_team = game_state['away'] if game_state['top_inning'] else game_state['home']
    pitching_team = game_state['home'] if game_state['top_inning'] else game_state['away']
    
    batter = batting_team['lineup'][batting_team['current_batter_index']] if batting_team['lineup'] else None
    pitcher = pitching_team['pitchers'][pitching_team['current_pitcher_index']] if pitching_team['pitchers'] else None
    
    return jsonify({
        'away_team': game_state['away']['name'],
        'away_abbr': game_state['away']['abbr'],
        'home_team': game_state['home']['name'],
        'home_abbr': game_state['home']['abbr'],
        'away_runs': game_state['away']['score']['R'],
        'away_hits': game_state['away']['score']['H'],
        'away_errors': game_state['away']['score']['E'],
        'home_runs': game_state['home']['score']['R'],
        'home_hits': game_state['home']['score']['H'],
        'home_errors': game_state['home']['score']['E'],
        'inning': game_state['inning'],
        'inning_half': 'TOP' if game_state['top_inning'] else 'BOTTOM',
        'outs': game_state['outs'],
        'balls': game_state['balls'],
        'strikes': game_state['strikes'],
        'base_1': game_state['bases']['first'],
        'base_2': game_state['bases']['second'],
        'base_3': game_state['bases']['third'],
        'current_batter': batter['name'] if batter else '',
        'batter_number': batter['number'] if batter else '',
        'batter_position': batter['position'] if batter else '',
        'current_pitcher': pitcher['name'] if pitcher else '',
        'pitcher_number': pitcher['number'] if pitcher else '',
        'pitch_count': pitcher['pitch_count'] if pitcher else 0
    })

@app.route('/api/scoreboard.json')
def scoreboard_json():
    """Scoreboard data for VMix"""
    pitching_team = game_state['home'] if game_state['top_inning'] else game_state['away']
    batting_team = game_state['away'] if game_state['top_inning'] else game_state['home']
    
    pitcher = pitching_team['pitchers'][pitching_team['current_pitcher_index']] if pitching_team['pitchers'] else None
    batter = batting_team['lineup'][batting_team['current_batter_index']] if batting_team['lineup'] else None
    
    # Get pitcher last name
    pitcher_last_name = ''
    if pitcher and pitcher['name']:
        name_parts = pitcher['name'].strip().split()
        pitcher_last_name = name_parts[-1] if name_parts else ''
    
    # Get batter last name with order number
    batter_display = ''
    if batter:
        batter_order = batting_team['current_batter_index'] + 1
        if batter['name']:
            name_parts = batter['name'].strip().split()
            batter_last_name = name_parts[-1] if name_parts else batter['name']
            batter_display = f"{batter_order}. {batter_last_name}"
        else:
            batter_display = f"{batter_order}. Player {batter_order}"
    
    return jsonify({
        'inning': game_state['inning'],
        'inning_half': 'TOP' if game_state['top_inning'] else 'BOTTOM',
        'balls': game_state['balls'],
        'strikes': game_state['strikes'],
        'outs': game_state['outs'],
        'away_team': game_state['away']['name'],
        'away_abbr': game_state['away']['abbr'],
        'away_runs': game_state['away']['score']['R'],
        'away_hits': game_state['away']['score']['H'],
        'away_errors': game_state['away']['score']['E'],
        'home_team': game_state['home']['name'],
        'home_abbr': game_state['home']['abbr'],
        'home_runs': game_state['home']['score']['R'],
        'home_hits': game_state['home']['score']['H'],
        'home_errors': game_state['home']['score']['E'],
        'current_pitcher_last_name': pitcher_last_name,
        'pitch_count': pitcher['pitch_count'] if pitcher else 0,
        'current_batter': batter_display
    })

@app.route('/api/homebatter.json')
def home_batter_json():
    """Home team current batter data"""
    home_batter = game_state['home']['lineup'][game_state['home']['current_batter_index']] if game_state['home']['lineup'] else None
    
    if not home_batter:
        return jsonify({
            'name': '',
            'number': '',
            'position': '',
            'at_bats': 0,
            'hits': 0,
            'avg': '.000',
            'game_line': 'No batter',
            'game_stats': {}
        })
    
    # Build game line (e.g., "2 for 3, 2B, HR")
    game_line_parts = []
    if home_batter['at_bats'] > 0:
        game_line_parts.append(f"{home_batter['hits']} for {home_batter['at_bats']}")
        
        # Add hit types
        hit_details = []
        for stat in ['1B', '2B', '3B', 'HR']:
            count = home_batter['game_stats'].get(stat, 0)
            if count > 0:
                if count > 1:
                    hit_details.append(f"{count} {stat}")
                else:
                    hit_details.append(stat)
        
        if hit_details:
            game_line_parts.append(', '.join(hit_details))
    else:
        game_line_parts.append('0 for 0')
    
    game_line = ', '.join(game_line_parts)
    
    # Calculate average
    avg = home_batter['hits'] / home_batter['at_bats'] if home_batter['at_bats'] > 0 else 0
    avg_str = f".{int(avg * 1000):03d}" if avg < 1 else "1.000"
    
    return jsonify({
        'name': home_batter['name'],
        'number': home_batter['number'],
        'position': home_batter['position'],
        'at_bats': home_batter['at_bats'],
        'hits': home_batter['hits'],
        'avg': avg_str,
        'game_line': game_line,
        'game_stats': home_batter['game_stats']
    })

@app.route('/api/awaybatter.json')
def away_batter_json():
    """Away team current batter data"""
    away_batter = game_state['away']['lineup'][game_state['away']['current_batter_index']] if game_state['away']['lineup'] else None
    
    if not away_batter:
        return jsonify({
            'name': '',
            'number': '',
            'position': '',
            'at_bats': 0,
            'hits': 0,
            'avg': '.000',
            'game_line': 'No batter',
            'game_stats': {}
        })
    
    # Build game line (e.g., "2 for 3, 2B, HR")
    game_line_parts = []
    if away_batter['at_bats'] > 0:
        game_line_parts.append(f"{away_batter['hits']} for {away_batter['at_bats']}")
        
        # Add hit types
        hit_details = []
        for stat in ['1B', '2B', '3B', 'HR']:
            count = away_batter['game_stats'].get(stat, 0)
            if count > 0:
                if count > 1:
                    hit_details.append(f"{count} {stat}")
                else:
                    hit_details.append(stat)
        
        if hit_details:
            game_line_parts.append(', '.join(hit_details))
    else:
        game_line_parts.append('0 for 0')
    
    game_line = ', '.join(game_line_parts)
    
    # Calculate average
    avg = away_batter['hits'] / away_batter['at_bats'] if away_batter['at_bats'] > 0 else 0
    avg_str = f".{int(avg * 1000):03d}" if avg < 1 else "1.000"
    
    return jsonify({
        'name': away_batter['name'],
        'number': away_batter['number'],
        'position': away_batter['position'],
        'at_bats': away_batter['at_bats'],
        'hits': away_batter['hits'],
        'avg': avg_str,
        'game_line': game_line,
        'game_stats': away_batter['game_stats']
    })

@app.route('/api/ball', methods=['POST'])
def add_ball():
    save_state_to_history()
    game_state['balls'] += 1
    pitching_team = game_state['home'] if game_state['top_inning'] else game_state['away']
    if pitching_team['pitchers']:
        pitcher = pitching_team['pitchers'][pitching_team['current_pitcher_index']]
        pitcher['pitch_count'] += 1
        pitcher['balls'] += 1
    if game_state['balls'] >= 4:
        # Record walk for pitcher
        if pitching_team['pitchers']:
            pitching_team['pitchers'][pitching_team['current_pitcher_index']]['walks'] += 1
        advance_bases(True)
        return jsonify({'success': True, 'next_batter_delay': 5})
    return jsonify({'success': True})

@app.route('/api/strike', methods=['POST'])
def add_strike():
    save_state_to_history()
    game_state['strikes'] += 1
    pitching_team = game_state['home'] if game_state['top_inning'] else game_state['away']
    if pitching_team['pitchers']:
        pitcher = pitching_team['pitchers'][pitching_team['current_pitcher_index']]
        pitcher['pitch_count'] += 1
        pitcher['strikes'] += 1
    if game_state['strikes'] >= 3:
        # Record strikeout for pitcher
        if pitching_team['pitchers']:
            pitching_team['pitchers'][pitching_team['current_pitcher_index']]['strikeouts'] += 1
        return jsonify({'success': True, 'action': 'strikeout'})
    return jsonify({'success': True})

@app.route('/api/foul', methods=['POST'])
def add_foul():
    save_state_to_history()
    pitching_team = game_state['home'] if game_state['top_inning'] else game_state['away']
    if pitching_team['pitchers']:
        pitcher = pitching_team['pitchers'][pitching_team['current_pitcher_index']]
        pitcher['pitch_count'] += 1
        pitcher['strikes'] += 1
    if game_state['strikes'] < 2:
        game_state['strikes'] += 1
    return jsonify({'success': True})

@app.route('/api/hit', methods=['POST'])
def record_hit():
    save_state_to_history()
    data = request.json
    hit_type = data['type']
    stat_map = {'single': '1B', 'double': '2B', 'triple': '3B', 'hr': 'HR'}
    stat = stat_map.get(hit_type, '1B')
    record_at_bat(stat, is_hit=True)
    
    # Record hit allowed for pitcher
    pitching_team = game_state['home'] if game_state['top_inning'] else game_state['away']
    if pitching_team['pitchers']:
        pitching_team['pitchers'][pitching_team['current_pitcher_index']]['hits_allowed'] += 1
    
    team = game_state['away'] if game_state['top_inning'] else game_state['home']
    
    # Only auto-score runs for home runs
    if hit_type == 'hr':
        runs = 1 + sum(game_state['bases'].values())
        team['score']['R'] += runs
        team['score']['H'] += 1
        game_state['bases'] = {'first': False, 'second': False, 'third': False}
        # Record runs allowed for pitcher
        if pitching_team['pitchers']:
            pitching_team['pitchers'][pitching_team['current_pitcher_index']]['runs_allowed'] += runs
    else:
        # For all other hits, just add to hit count and advance bases manually
        # Runs will be tracked manually by the user
        if hit_type == 'single':
            advance_bases_hit(1)
        elif hit_type == 'double':
            advance_bases_hit(2)
        elif hit_type == 'triple':
            advance_bases_hit(3)
    
    return jsonify({'success': True, 'next_batter_delay': 5})

@app.route('/api/out', methods=['POST'])
def record_out():
    save_state_to_history()
    return jsonify({'success': True, 'action': 'out'})

@app.route('/api/strikeout', methods=['POST'])
def record_strikeout():
    save_state_to_history()
    return jsonify({'success': True, 'action': 'strikeout'})

@app.route('/api/walk', methods=['POST'])
def record_walk():
    save_state_to_history()
    record_at_bat('BB')
    advance_bases(True)
    return jsonify({'success': True, 'next_batter_delay': 5})

@app.route('/api/hbp', methods=['POST'])
def record_hbp():
    save_state_to_history()
    record_at_bat('HBP')
    advance_bases(True)
    return jsonify({'success': True, 'next_batter_delay': 5})

@app.route('/api/roe', methods=['POST'])
def record_roe():
    save_state_to_history()
    record_at_bat('ROE')
    advance_bases(True)
    team = game_state['home'] if game_state['top_inning'] else game_state['away']
    team['score']['E'] += 1
    return jsonify({'success': True, 'next_batter_delay': 5})

@app.route('/api/reset-count', methods=['POST'])
def reset_count():
    save_state_to_history()
    game_state['balls'] = 0
    game_state['strikes'] = 0
    return jsonify({'success': True})

@app.route('/api/reset-outs', methods=['POST'])
def reset_outs():
    save_state_to_history()
    game_state['outs'] = 0
    return jsonify({'success': True})

@app.route('/api/manual-inning', methods=['POST'])
def manual_inning():
    save_state_to_history()
    data = request.json
    game_state['inning'] = data['inning']
    game_state['top_inning'] = data['top']
    game_state['outs'] = 0
    game_state['balls'] = 0
    game_state['strikes'] = 0
    game_state['bases'] = {'first': False, 'second': False, 'third': False}
    return jsonify({'success': True})

@app.route('/api/reset', methods=['POST'])
def reset_game():
    game_state['inning'] = 1
    game_state['top_inning'] = True
    game_state['outs'] = 0
    game_state['balls'] = 0
    game_state['strikes'] = 0
    game_state['bases'] = {'first': False, 'second': False, 'third': False}
    game_state['away']['score'] = {'R': 0, 'H': 0, 'E': 0}
    game_state['home']['score'] = {'R': 0, 'H': 0, 'E': 0}
    game_state['away']['current_batter_index'] = 0
    game_state['home']['current_batter_index'] = 0
    game_state['away']['current_pitcher_index'] = 0
    game_state['home']['current_pitcher_index'] = 0
    for team in [game_state['away'], game_state['home']]:
        for player in team['lineup']:
            player['at_bats'] = 0
            player['hits'] = 0
            player['game_stats'] = {'1B': 0, '2B': 0, '3B': 0, 'HR': 0, 'BB': 0, 'K': 0, 'OUT': 0}
        for pitcher in team['pitchers']:
            pitcher['pitch_count'] = 0
            pitcher['strikes'] = 0
            pitcher['balls'] = 0
            pitcher['outs_recorded'] = 0
            pitcher['strikeouts'] = 0
            pitcher['walks'] = 0
            pitcher['hits_allowed'] = 0
            pitcher['runs_allowed'] = 0
    return jsonify({'success': True})

@app.route('/api/manual-score', methods=['POST'])
def manual_score():
    save_state_to_history()
    data = request.json
    team = game_state['away'] if game_state['top_inning'] else game_state['home']
    team['score'][data['stat']] = max(0, team['score'][data['stat']] + data['delta'])
    return jsonify({'success': True})

@app.route('/api/team-score', methods=['POST'])
def team_score():
    """Update score for a specific team (away or home)"""
    save_state_to_history()
    data = request.json
    team = game_state[data['team']]
    team['score'][data['stat']] = max(0, team['score'][data['stat']] + data['delta'])
    return jsonify({'success': True})

@app.route('/api/manual-out', methods=['POST'])
def manual_out():
    """Add an out without affecting player stats"""
    save_state_to_history()
    game_state['outs'] += 1
    game_state['balls'] = 0
    game_state['strikes'] = 0
    
    if game_state['outs'] >= 3:
        return jsonify({'success': True, 'inning_change_delay': 15})
    else:
        return jsonify({'success': True, 'next_batter_delay': 5})
    return jsonify({'success': True})

@app.route('/api/team-info', methods=['POST'])
def update_team_info():
    data = request.json
    game_state[data['team']][data['field']] = data['value']
    return jsonify({'success': True})

@app.route('/api/update-player', methods=['POST'])
def update_player():
    data = request.json
    game_state[data['team']]['lineup'][data['index']][data['field']] = data['value']
    return jsonify({'success': True})

@app.route('/api/update-pitcher', methods=['POST'])
def update_pitcher():
    data = request.json
    game_state[data['team']]['pitchers'][data['index']][data['field']] = data['value']
    return jsonify({'success': True})

@app.route('/api/add-pitcher', methods=['POST'])
def add_pitcher():
    data = request.json
    game_state[data['team']]['pitchers'].append(init_pitcher())
    return jsonify({'success': True})

@app.route('/api/substitute-batter', methods=['POST'])
def substitute_batter():
    data = request.json
    team = game_state['away'] if game_state['top_inning'] else game_state['home']
    team['current_batter_index'] = data['index']
    game_state['balls'] = 0
    game_state['strikes'] = 0
    return jsonify({'success': True})

@app.route('/api/substitute-pitcher', methods=['POST'])
def substitute_pitcher():
    data = request.json
    team = game_state['home'] if game_state['top_inning'] else game_state['away']
    team['current_pitcher_index'] = data['index']
    return jsonify({'success': True})

@app.route('/api/next-batter', methods=['POST'])
def api_next_batter():
    """Advance to next batter"""
    next_batter()
    return jsonify({'success': True})

@app.route('/api/change-inning', methods=['POST'])
def api_change_inning():
    """Change to next inning"""
    change_inning()
    return jsonify({'success': True})

def record_at_bat(stat, is_out=False, is_hit=False, auto_advance=True):
    team = game_state['away'] if game_state['top_inning'] else game_state['home']
    pitching_team = game_state['home'] if game_state['top_inning'] else game_state['away']
    
    if team['lineup']:
        batter = team['lineup'][team['current_batter_index']]
        batter['at_bats'] += 1
        if is_hit:
            batter['hits'] += 1
            team['score']['H'] += 1
        batter['game_stats'][stat] = batter['game_stats'].get(stat, 0) + 1
    
    if is_out:
        game_state['outs'] += 1
        # Record out for pitcher
        if pitching_team['pitchers']:
            pitching_team['pitchers'][pitching_team['current_pitcher_index']]['outs_recorded'] += 1
        
        if game_state['outs'] >= 3:
            if auto_advance:
                return 'inning_change'
        else:
            if auto_advance:
                return 'next_batter'
    return None

def advance_bases(force):
    if force:
        team = game_state['away'] if game_state['top_inning'] else game_state['home']
        if game_state['bases']['first']:
            if game_state['bases']['second']:
                if game_state['bases']['third']:
                    team['score']['R'] += 1
                game_state['bases']['third'] = True
            game_state['bases']['second'] = True
        game_state['bases']['first'] = True
    game_state['balls'] = 0
    game_state['strikes'] = 0

def advance_bases_hit(bases):
    team = game_state['away'] if game_state['top_inning'] else game_state['home']
    new_bases = {'first': False, 'second': False, 'third': False}
    
    # No automatic run scoring - just advance bases
    # Runners stay on bases, no scoring
    if bases == 1:
        if game_state['bases']['second']:
            new_bases['third'] = True
        if game_state['bases']['first']:
            new_bases['second'] = True
        new_bases['first'] = True
    elif bases == 2:
        if game_state['bases']['first']:
            new_bases['third'] = True
        new_bases['second'] = True
    elif bases == 3:
        new_bases['third'] = True
    
    game_state['bases'] = new_bases
    game_state['balls'] = 0
    game_state['strikes'] = 0

def next_batter():
    team = game_state['away'] if game_state['top_inning'] else game_state['home']
    if team['lineup']:
        team['current_batter_index'] = (team['current_batter_index'] + 1) % 9
    game_state['balls'] = 0
    game_state['strikes'] = 0

def change_inning():
    game_state['outs'] = 0
    game_state['balls'] = 0
    game_state['strikes'] = 0
    game_state['bases'] = {'first': False, 'second': False, 'third': False}
    if game_state['top_inning']:
        game_state['top_inning'] = False
    else:
        game_state['top_inning'] = True
        game_state['inning'] += 1

if __name__ == '__main__':
    print("Baseball Scoreboard Server")
    print("=" * 50)
    print("Server starting on http://0.0.0.0:5000")
    print("Access from iPad: http://[YOUR_PC_IP]:5000")
    print("")
    print("VMix JSON Endpoints:")
    print("  Scoreboard:   http://[YOUR_PC_IP]:5000/api/scoreboard.json")
    print("  Home Batter:  http://[YOUR_PC_IP]:5000/api/homebatter.json")
    print("  Away Batter:  http://[YOUR_PC_IP]:5000/api/awaybatter.json")
    print("=" * 50)
    app.run(host='0.0.0.0', port=5000, debug=True)